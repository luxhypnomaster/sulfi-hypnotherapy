Сервер Проекта Алхимик — комплект исходников №16.

Секретов, owner sub и скомпилированного InitialConfig здесь нет. Этот архив не объявляет сервер живым. Вручную вставлять код не требуется: deploy.mjs запускается только доверенным main workflow, использует repository secret CLASPRC_JSON и подставляет проверенную конфигурацию в RUNNER_TEMP.

Реальный проект уже создан и закреплён в private repo; не создавайте второй. Статус deployment/версия/URL — только в актуальных RESULT/CLOUD_ACCESS/PROGRESS и GitHub evidence, не в этом исходном комплекте.

Полный source включает Catalog/Diary/Media/Packages/Grants/Sync/Storage, RSA vendor, manifest и tests. compiled/gas без InitialConfig остаётся ненастроенным по health — это намеренная защита от ложного LIVE. Старый дневник не изменять.
